/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';

interface BearHeroIllustrationProps {
  swirlTrigger?: number;
}

export function BearHeroIllustration({ swirlTrigger = 0 }: BearHeroIllustrationProps) {
  const [isAssembled, setIsAssembled] = useState(false);

  return (
    <div className="relative w-[210px] sm:w-[240px] md:w-[265px] flex items-center justify-center select-none">
      {/* ─────────────────────────────────────────────────────────────
          CONSTRUCTION-INSPIRED PRELOADER / ENTRANCE HUD
          Architectural registration brackets, laser leveling scan,
          and blueprint coordinate markers (Hero Section Only)
          ───────────────────────────────────────────────────────────── */}

      {/* Preloader Technical Status Pill (Fades out when assembled) */}
      <motion.div
        initial={{ opacity: 0, y: 8, scale: 0.92 }}
        animate={{
          opacity: [0, 1, 1, 0],
          y: [8, 0, 0, -6],
          scale: [0.92, 1, 1, 0.95],
        }}
        transition={{
          duration: 1.7,
          times: [0, 0.18, 0.8, 1],
          ease: 'easeInOut',
        }}
        className="absolute -top-7 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-[#41474D]/90 backdrop-blur-xs border border-[#4d5a26]/40 shadow-sm text-[#FDFAF2] text-[8px] sm:text-[9px] font-mono tracking-widest uppercase flex items-center gap-1.5 pointer-events-none z-30 whitespace-nowrap"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-[#4d5a26] animate-ping" />
        <span>CONSTRUCTING // FOUNDATION</span>
      </motion.div>

      {/* Architectural Corner Registration Brackets (Top-Left, Top-Right, Bottom-Left, Bottom-Right) */}
      <motion.div
        initial={{ opacity: 0, scale: 0.94 }}
        animate={{
          opacity: [0, 0.65, 0.65, 0],
          scale: [0.94, 1, 1, 1.02],
        }}
        transition={{
          duration: 1.8,
          times: [0, 0.2, 0.8, 1],
          ease: 'easeOut',
        }}
        className="absolute -inset-3 sm:-inset-4 pointer-events-none z-20 flex flex-col justify-between"
      >
        {/* Top pair */}
        <div className="flex justify-between items-start font-mono text-[8px] sm:text-[9px] text-[#41474D]/60 select-none">
          <span className="leading-none tracking-tighter">┌ 01-ELEV</span>
          <span className="leading-none tracking-tighter">AXIS-B ┐</span>
        </div>
        {/* Bottom pair */}
        <div className="flex justify-between items-end font-mono text-[8px] sm:text-[9px] text-[#41474D]/60 select-none">
          <span className="leading-none tracking-tighter">└ LVL 0.0</span>
          <span className="leading-none tracking-tighter">SPEC-1.0 ┘</span>
        </div>
      </motion.div>

      {/* Laser Leveling Beam (Sweeps from foundation step upward to head) */}
      <motion.div
        initial={{ top: '100%', opacity: 0 }}
        animate={{
          top: ['100%', '-2%'],
          opacity: [0, 0.85, 0.85, 0],
        }}
        transition={{
          duration: 1.35,
          times: [0, 0.15, 0.85, 1],
          ease: 'easeInOut',
        }}
        className="absolute left-[-10%] right-[-10%] h-[1.5px] bg-gradient-to-r from-transparent via-[#4d5a26] to-transparent pointer-events-none z-20"
        style={{
          boxShadow: '0 0 10px rgba(77, 90, 38, 0.7)',
        }}
      >
        {/* Central precision leveling pip */}
        <div className="absolute left-1/2 -top-[3.5px] -translate-x-1/2 w-2 h-2 rounded-full bg-[#4d5a26] border border-[#FDFAF2] shadow-xs" />
      </motion.div>

      {/* ─────────────────────────────────────────────────────────────
          BEAR SVG VECTOR ILLUSTRATION
          Architectural blueprint line drafting -> rich material fill
          and masonry foundation settling
          ───────────────────────────────────────────────────────────── */}
      <motion.svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 1773 2048"
        className="w-full h-auto max-h-[240px] md:max-h-[265px] object-contain select-none pointer-events-none"
        initial={{ y: 24, opacity: 0, scale: 0.95 }}
        animate={{
          y: [24, -2, 0],
          opacity: 1,
          scale: 1,
        }}
        transition={{
          duration: 1.3,
          ease: [0.16, 1, 0.3, 1],
        }}
        onAnimationComplete={() => setIsAssembled(true)}
        style={{
          filter: 'drop-shadow(0 8px 16px rgba(0,0,0,0.18))',
        }}
        key={`hero-bear-${swirlTrigger}`}
      >
        <g id="logo-emblem">
          {/* Path 1: Bear Inner Ear Contour (Slate #41474D) */}
          <motion.path
            d="M 671.201 586.328 C 673.521 586.211 675.844 586.147 678.167 586.135 C 714.69 585.657 752.842 599.843 713.058 637.378 C 693.63 632.669 673.634 636.687 657.715 648.357 C 648.445 655.151 634.408 669.29 632.467 680.79 C 633.025 682.136 633.809 684.122 635.823 683.749 C 677.596 676.02 692.43 665.387 707.814 713.538 C 697.087 720.158 689.616 722.124 677.687 726.062 C 666.221 730.258 653.284 733.965 641.568 738.171 C 633.049 741.23 615.624 748.121 607.698 749.578 C 596.844 751.486 585.676 749.005 576.651 742.68 C 568.152 736.752 560.978 725.86 559.783 715.471 C 554.915 673.133 578.578 629.568 614.295 607.195 C 634.339 594.639 647.921 590.344 671.201 586.328 z"
            stroke="#41474D"
            strokeWidth={10}
            initial={{ pathLength: 0, fill: 'rgba(65, 71, 77, 0)', strokeOpacity: 0.8 }}
            animate={{
              pathLength: 1,
              fill: 'rgba(65, 71, 77, 1)',
              strokeOpacity: [0.8, 1, 0],
            }}
            transition={{
              pathLength: { duration: 0.9, ease: 'easeInOut' },
              fill: { delay: 0.6, duration: 0.5, ease: 'easeOut' },
              strokeOpacity: { delay: 0.9, duration: 0.4 },
            }}
          />

          {/* Path 2: Bear Eye (Slate #41474D) */}
          <motion.path
            d="M 1125.26 1028.37 C 1165.12 1023.36 1201.55 1051.46 1206.82 1091.28 C 1212.09 1131.11 1184.22 1167.72 1144.43 1173.24 C 1104.28 1178.81 1067.27 1150.63 1061.95 1110.45 C 1056.64 1070.26 1085.05 1033.43 1125.26 1028.37 z"
            stroke="#41474D"
            strokeWidth={10}
            initial={{ pathLength: 0, fill: 'rgba(65, 71, 77, 0)', strokeOpacity: 0.8 }}
            animate={{
              pathLength: 1,
              fill: 'rgba(65, 71, 77, 1)',
              strokeOpacity: [0.8, 1, 0],
            }}
            transition={{
              pathLength: { duration: 0.9, ease: 'easeInOut', delay: 0.15 },
              fill: { delay: 0.65, duration: 0.5, ease: 'easeOut' },
              strokeOpacity: { delay: 0.95, duration: 0.4 },
            }}
          />

          {/* Path 3: Bear Body & Head Silhouette (Slate #41474D) */}
          <motion.path
            d="M 369.791 535.191 C 527.812 286.823 938.74 273.084 1002.41 585.905 C 1004.16 594.494 1004.64 612.28 1009.1 618 C 1014.4 620.112 1029.75 621.323 1036.12 622.111 C 1203.3 642.791 1365.89 734.098 1455.87 878.894 C 1468.02 898.449 1476.86 921.102 1492.54 937.324 C 1523.68 958.788 1578.68 982.304 1613.74 996.322 C 1641.51 1007.44 1669.46 1018.09 1697.59 1028.27 C 1716.94 1035.37 1737.85 1040.92 1755.55 1051.3 C 1766.33 1057.62 1766.77 1071.25 1773 1078.05 L 1773 1118.61 C 1771.47 1120.1 1769.65 1122.11 1769.28 1124.28 C 1762.58 1163.37 1755.43 1202.04 1744.5 1240.24 C 1730.12 1291.37 1709.38 1340.49 1682.77 1386.45 C 1615.96 1501.52 1513.04 1578.95 1389.66 1622.68 C 1310.08 1649.82 1233.89 1677.25 1182.37 1748.47 C 1170.8 1764.47 1164.71 1786.31 1137.38 1784.5 C 1134.89 1784.33 1130.78 1784.27 1128.43 1783.42 C 1059.16 1758.21 1152.26 1670.75 1173.59 1650.84 C 1251.1 1578.46 1355.68 1565.69 1445.49 1516.96 C 1516.96 1478.29 1576.89 1421.32 1619.12 1351.88 C 1637.41 1321.97 1652.04 1291.52 1663.06 1258.23 C 1664.36 1254.29 1670.19 1243.08 1666.67 1240.15 C 1660.32 1234.86 1650.11 1233.97 1643.06 1228.99 C 1603.28 1206.59 1574.38 1165.58 1579.04 1118.47 C 1580.53 1103.38 1581.9 1089.71 1591.66 1077.07 C 1594.64 1073.22 1596.2 1072.54 1594.43 1069.76 C 1583.76 1063.68 1570.78 1059.76 1559.54 1054.74 C 1522.11 1038.1 1475.98 1021.32 1443 997.616 C 1424.9 984.605 1406.83 941.941 1394.46 922.335 C 1312.54 792.517 1174.19 715.308 1023.53 696.164 C 993.611 692.363 944.695 696.745 935.559 661.909 C 933.266 653.784 933.686 639.236 933.064 631.144 C 917.332 429.804 709.596 379.191 552.279 467.187 C 449.318 524.779 345.872 658.851 413.693 781.638 C 431.424 813.738 461.395 844.904 419.157 874.747 C 404.73 884.939 391.062 894.775 377.658 905.728 C 309.701 961.257 247.767 1034.16 207.394 1112.19 C 148.638 1224.43 130.078 1353.4 154.802 1477.66 C 187.19 1632.62 294.437 1773.95 426.113 1859.68 C 504.578 1911.82 592.989 1947.14 685.776 1963.43 C 757.132 1976.28 824.676 1976.35 895.754 1962.71 C 918.471 1958.35 944.427 1945.43 964.837 1958.91 C 987.447 1973.04 986.093 2011.53 960.662 2021.43 C 935.981 2031.03 905.584 2035.04 879.447 2040.09 C 869.375 2041.96 851.042 2041.57 845.579 2048 L 725.347 2048 C 720.937 2042.62 711.024 2043.35 703.069 2042.3 C 502.142 2015.32 320.504 1908.68 199.026 1746.38 C 43.1482 1540.23 25.8554 1277.47 155.907 1053.57 C 188.004 997.064 227.272 944.949 272.733 898.517 C 294.788 876.316 329.199 848.947 354.018 830.233 C 331.607 788.208 317.957 754.328 315.903 705.465 C 314.632 675.222 322.757 636.968 333.199 608.668 C 336.426 599.922 341.423 587.01 344.491 577.934 C 344.181 576.97 343.871 576.005 343.561 575.04 C 345.139 574.797 346.337 574.217 347.202 572.718 C 354.708 559.711 360.509 547.127 369.791 535.191 z M 1685 1174.8 C 1692.57 1156.57 1693.72 1127.5 1696.4 1107.01 C 1680.88 1099.38 1671.89 1097.83 1656.69 1092.11 C 1650.23 1109.69 1642.32 1125.64 1650.72 1145.01 C 1654.77 1154.35 1674.6 1171.44 1682.98 1174.97 L 1685 1174.8 z"
            stroke="#41474D"
            strokeWidth={7}
            initial={{ pathLength: 0, fill: 'rgba(65, 71, 77, 0)', strokeOpacity: 0.85 }}
            animate={{
              pathLength: 1,
              fill: 'rgba(65, 71, 77, 1)',
              strokeOpacity: [0.85, 1, 0],
            }}
            transition={{
              pathLength: { duration: 1.15, ease: [0.25, 1, 0.5, 1] },
              fill: { delay: 0.6, duration: 0.65, ease: 'easeOut' },
              strokeOpacity: { delay: 1.05, duration: 0.35 },
            }}
          />

          {/* Path 4: Botanical Sprout on Head (Deep Olive #4d5a26) */}
          <motion.path
            d="M 591.432 0 L 628.549 0 C 630.735 5.98357 630.289 20.2212 630.243 27.047 C 629.636 81.4642 617.218 135.1 593.849 184.248 C 568.532 238.042 523.669 290.029 470.669 317.747 C 435.987 335.886 398.142 350.166 358.57 350.326 C 345.859 372.35 337.638 411.5 336.322 436.79 C 334.786 466.328 346.464 515.113 369.791 535.191 C 360.509 547.127 354.708 559.711 347.202 572.718 C 346.337 574.217 345.139 574.797 343.561 575.04 C 322.415 537.15 295.942 502.491 264.95 472.123 C 234.764 479.565 217.494 484.493 186.027 480.725 C 99.8336 470.405 34.0638 399.8 12.1832 318.444 C 9.03677 306.745 5.34745 269.564 0.582106 263.744 C 0.392887 263.513 0.194035 263.29 0 263.063 L 0 256.531 C 10.6998 250.235 41.5247 250.388 55.1732 250.325 C 156.461 249.851 260.55 310.702 284.694 413.747 C 286.788 422.684 286.004 436.471 285.904 445.92 C 289.29 448.272 292.434 450.766 296.257 452.217 C 298.899 448.42 299.657 426.277 300.492 418.897 C 304.096 387.033 311.457 366.624 322.567 337.138 C 320.028 328.856 315.096 318.829 313.375 310.578 C 284.42 171.756 389.557 57.1083 513.761 19.4805 C 529.979 14.399 546.512 10.3826 563.254 7.4567 C 571.6 6.0501 585.531 5.54372 591.432 0 z"
            stroke="#4d5a26"
            strokeWidth={8}
            initial={{ pathLength: 0, fill: 'rgba(77, 90, 38, 0)', strokeOpacity: 0.9 }}
            animate={{
              pathLength: 1,
              fill: 'rgba(77, 90, 38, 1)',
              strokeOpacity: [0.9, 1, 0],
            }}
            transition={{
              pathLength: { delay: 0.25, duration: 0.95, ease: 'easeInOut' },
              fill: { delay: 0.65, duration: 0.55, ease: 'easeOut' },
              strokeOpacity: { delay: 1.05, duration: 0.35 },
            }}
          />
        </g>
      </motion.svg>
    </div>
  );
}
