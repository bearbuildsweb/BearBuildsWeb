import React from "react";
import { motion } from "motion/react";
import { ArrowDown, MessageCircle, Menu } from "lucide-react";
// @ts-ignore
import bearPortrait from "../assets/images/hero-UPDATE.png";

interface HeroProps {
  onRequestSiteClick?: () => void;
  onContactClick: () => void;
  onWhoIHelpClick: () => void;
  onToggleMenu: () => void;
}

export default function Hero({ onRequestSiteClick, onContactClick, onWhoIHelpClick, onToggleMenu }: HeroProps) {
  return (
    <section className="relative w-full px-2 sm:px-4 lg:px-8 pt-2 pb-16 lg:pb-24 overflow-hidden bg-[#ECEEF1]">
      
      {/* Outer Framed Editorial Poster Canvas */}
      <div className="relative max-w-[1440px] mx-auto rounded-[28px] sm:rounded-[38px] lg:rounded-[48px] overflow-hidden border border-[#18181B]/15 shadow-[0_35px_90px_rgba(24,24,27,0.08)] bg-gradient-to-b from-[#18191B] via-[#2A2C31] via-55% to-[#F4F5F7] to-90%">
        
        {/* Subtle Fine Geometric Grid & Texture */}
        <div className="absolute inset-0 bg-[radial-gradient(#FFFFFF_1.2px,transparent_1.2px)] [background-size:32px_32px] opacity-15 pointer-events-none" />
        
        {/* Radial Architectural Glow behind Center */}
        <div className="absolute top-[26%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[420px] sm:w-[600px] lg:w-[780px] aspect-square rounded-full bg-black/40 blur-[90px] pointer-events-none" />

        {/* Poster Registration Marks (Brutalist Top Corners) */}
        <div className="absolute top-4 left-4 sm:top-6 sm:left-6 font-mono text-[9px] text-white/30 select-none pointer-events-none hidden sm:block">
          + 33.9249° S / 18.4241° E
        </div>
        <div className="absolute top-4 right-4 sm:top-6 right-6 font-mono text-[9px] text-white/30 select-none pointer-events-none hidden sm:block">
          SYS.V26 // CAPE TOWN
        </div>

        {/* Top Header / Brand Bar inside the Editorial Card */}
        <div className="relative z-30 px-5 sm:px-10 lg:px-14 pt-5 sm:pt-7 pb-4 flex items-center justify-between border-b border-white/10 backdrop-blur-[2px]">
          
          {/* Brand Emblem & Tagline */}
          <motion.div 
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center gap-3 group cursor-pointer"
            onClick={onContactClick}
          >
            {/* Bear Emblem Circle */}
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-white/15 border border-white/30 backdrop-blur-md flex items-center justify-center text-white shadow-sm transition-transform duration-300 group-hover:scale-105 group-hover:bg-white/25">
              <span className="text-base sm:text-lg">🐻</span>
            </div>
            <div className="flex flex-col">
              <span className="font-sans text-[12px] sm:text-[13px] font-extrabold tracking-wider text-white uppercase leading-tight antialiased">
                BEAR BUILDS WEB
              </span>
              <span className="font-sans text-[10px] sm:text-[11px] font-semibold tracking-wider text-zinc-300 uppercase antialiased">
                YOUR TOOLS. ONE PLACE.
              </span>
            </div>
          </motion.div>

          {/* Top-Right Editorial Nav: Hamburger Menu + WhatsApp Chat Bubble Action */}
          <motion.div 
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="flex items-center gap-3 sm:gap-4 font-mono text-[11px] uppercase tracking-wider text-white/90"
          >
            {/* Hamburger Icon Toggle */}
            <button
              onClick={onToggleMenu}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full border border-white/40 bg-white/15 hover:bg-white/25 hover:border-white text-white transition-all duration-300 flex items-center justify-center cursor-pointer backdrop-blur-md shadow-sm group hover:scale-105"
              title="Open Navigation Menu"
              aria-label="Open Navigation Menu"
            >
              <Menu className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" />
            </button>

            {/* WhatsApp Chat Bubble */}
            <a
              href={`https://wa.me/27680246914?text=${encodeURIComponent(
                "Hi Bear, I’d like to talk about building a DIGITAL FRONT DOOR for my work."
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full border border-white/40 bg-white/15 hover:bg-[#25D366] hover:border-[#25D366] hover:text-white text-white transition-all duration-300 flex items-center justify-center cursor-pointer backdrop-blur-md shadow-sm group hover:scale-105"
              title="Chat with Bear on WhatsApp"
              aria-label="WhatsApp Contact"
            >
              <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 group-hover:scale-110 transition-transform" />
            </a>
          </motion.div>

        </div>

        {/* Hero Central Stage: Integrated Art-Directed Headline & Overlapping Portrait */}
        <div className="relative z-20 px-3 sm:px-8 lg:px-14 pt-4 sm:pt-8 pb-12 sm:pb-20 flex flex-col items-center">
          
          {/* Brutalist Editorial Container with Depth Stacking */}
          <div className="relative w-full max-w-6xl mx-auto flex flex-col items-center justify-center mt-2 sm:mt-4">
            
            {/* Background Layer: Massive Architectural "YOUR TOOLS" Headline */}
            <motion.div 
              initial={{ opacity: 0, y: -25, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
              className="w-full text-center select-none relative z-10"
            >
              {/* Micro Tag Floating Above "YOUR TOOLS" */}
              <div className="inline-flex items-center gap-2 mb-2 sm:mb-3 px-3.5 py-1 rounded-full bg-white/15 border border-white/30 text-white font-sans text-[10px] sm:text-[11px] font-bold tracking-wider uppercase antialiased shadow-xs">
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse shrink-0" />
                <span className="font-bold text-white tracking-wider">DEAR PHOTOGRAPHER</span>
              </div>

              <h1 className="font-display font-black text-[18vw] sm:text-[15vw] lg:text-[155px] xl:text-[180px] text-white/95 leading-[0.80] tracking-tight uppercase drop-shadow-[0_8px_20px_rgba(0,0,0,0.18)]">
                YOUR TOOLS
              </h1>
            </motion.div>

            {/* Overlapping Central Composition: Image Capsule breaking the grid + Dramatic "Better experience." */}
            <div className="relative w-full flex flex-col lg:flex-row items-center justify-center -mt-10 sm:-mt-20 md:-mt-24 lg:-mt-28 z-20">
              {/* Central Art-Directed Photograph Capsule (Offset & Breaking the Grid) */}
              <motion.div 
                initial={{ opacity: 0, scale: 0.88, y: 35, rotate: -3 }}
                animate={{ opacity: 1, scale: 1, y: 0, rotate: -1.5 }}
                whileHover={{ rotate: 0, scale: 1.02 }}
                transition={{ duration: 0.9, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
                className="relative w-56 sm:w-68 md:w-80 lg:w-[330px] aspect-[10/13] group shrink-0 cursor-pointer my-4 lg:my-0"
              >
                {/* Brutalist Wireframe Offset Shadow Frame */}
                <div className="absolute inset-0 translate-x-3 translate-y-3 sm:translate-x-4 sm:translate-y-4 rounded-t-full rounded-b-[40px] border-2 border-dashed border-[#18181B]/30 bg-[#18181B]/5 pointer-events-none transition-transform duration-500 group-hover:translate-x-2 group-hover:translate-y-2" />
                
                {/* Secondary Ambient Halo Ring */}
                <div className="absolute -inset-3 rounded-t-full rounded-b-[44px] border border-white/30 pointer-events-none transition-transform duration-500 group-hover:scale-102" />

                {/* Corner Film Crop Marks */}
                <div className="hidden sm:flex absolute -top-3 -left-3 font-mono text-xs text-white font-bold bg-[#18181B] w-6 h-6 rounded-md border border-white/20 shadow-md z-30 items-center justify-center leading-none">
                  *
                </div>
                <div className="absolute -bottom-3 -right-3 font-sans text-[10px] text-[#18181B] font-bold bg-white px-2.5 py-1 rounded-full border border-[#18181B]/20 shadow-md z-30 tracking-wider uppercase antialiased">
                  SOUTH AFRICA
                </div>

                {/* Main Mask Capsule with Grayscale-to-Color Editorial Grading */}
                <div className="relative w-full h-full rounded-t-full rounded-b-[38px] overflow-hidden border-[4px] border-white bg-gradient-to-b from-[#2C2E33] via-[#484C55] to-[#E2E4E9] shadow-[0_30px_70px_rgba(24,24,27,0.30)]">
                  <img 
                    src={bearPortrait} 
                    alt="Moemedi 'Bear' Leeu - Web Specialist & Developer" 
                    className="w-full h-full object-cover grayscale contrast-[105%] group-hover:grayscale-[20%] group-hover:scale-106 transition-all duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                  {/* Subtle lighting vignette and bottom tone blend */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#18181B]/40 via-transparent to-transparent pointer-events-none" />
                </div>

              </motion.div>

              {/* Forefront Accent Word: "One Experience" with High Contrast #ebeaea Presentation (Hidden on mobile) */}
              <motion.div 
                initial={{ opacity: 0, x: 30, y: 15 }}
                animate={{ opacity: 1, x: 0, y: 0 }}
                transition={{ duration: 0.85, delay: 0.25, ease: [0.16, 1, 0.3, 1] }}
                className="hidden sm:block mt-4 lg:mt-0 lg:ml-4 xl:ml-6 text-center lg:text-left z-25 select-none"
              >
                <div className="relative inline-block">
                  <span className="font-serif italic font-semibold text-3xl sm:text-5xl md:text-6xl lg:text-[76px] xl:text-[96px] text-[#ebeaea] leading-[0.9] tracking-tight drop-shadow-[0_4px_24px_rgba(0,0,0,0.65)] block whitespace-nowrap">
                    One Experience.
                  </span>
                  
                  {/* Accent Dot beside the Serif Period */}
                  <span className="inline-block absolute bottom-1 sm:bottom-3 md:bottom-4 -right-2 sm:-right-3 w-1.5 sm:w-2.5 h-1.5 sm:h-2.5 rounded-full bg-[#ebeaea]/80 shadow-xs" />
                </div>
              </motion.div>

            </div>

          </div>

          {/* Editorial Content Section Below Composition */}
          <motion.div 
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, delay: 0.4 }}
            className="w-full max-w-2xl mt-8 sm:mt-12 lg:mt-16 flex flex-col items-center text-center space-y-6"
          >
            {/* Scrapbook Note Artifact: Pinned / Taped Personal Note */}
            <div className="relative max-w-xl mx-auto w-full group">
              {/* Pinned Washi Tape Strip at top */}
              <div className="absolute -top-3 left-8 sm:left-12 z-20 w-16 sm:w-20 h-4 bg-[#E5E7EB]/90 backdrop-blur-xs border-y border-[#18181B]/10 shadow-[0_1px_3px_rgba(0,0,0,0.06)] -rotate-2 select-none pointer-events-none opacity-85 group-hover:rotate-0 transition-transform duration-300" />

              {/* The Tactile Paper Card */}
              <div className="relative bg-white sm:bg-[#F8F9FA] border border-[#18181B]/12 rounded-2xl p-5 sm:p-7 shadow-[0_10px_35px_-8px_rgba(24,24,27,0.08),0_2px_4px_rgba(24,24,27,0.03)] -rotate-[0.6deg] sm:-rotate-1 group-hover:rotate-0 transition-transform duration-500 ease-out text-left">
                
                {/* Micro Editorial Annotation Header */}
                <div className="flex items-center justify-between gap-3 pb-3 mb-3 border-b border-[#18181B]/8 select-none">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#52525B]" />
                    <span className="font-mono text-[9px] sm:text-[10px] font-bold tracking-[0.18em] uppercase text-[#52525B]">
                      A NOTE // FROM BEAR
                    </span>
                  </div>
                  {/* Mounting Bolt matching Hero Footer */}
                  <div 
                    className="w-3.5 h-3.5 rounded-full bg-gradient-to-br from-[#F3F4F6] via-[#D1D5DB] to-[#9CA3AF] border border-[#18181B]/30 shadow-[inset_0_1px_1px_rgba(255,255,255,0.7),0_1px_2px_rgba(0,0,0,0.12)] flex items-center justify-center rotate-[38deg] select-none shrink-0" 
                    title="Mounting Bolt" 
                    aria-hidden="true"
                  >
                    <div className="relative w-2 h-2 flex items-center justify-center">
                      <div className="absolute w-1.5 h-px bg-[#18181B]/60 rounded-xs shadow-[0_0.5px_0.5px_rgba(0,0,0,0.4)]" />
                      <div className="absolute h-1.5 w-px bg-[#18181B]/60 rounded-xs shadow-[0_0.5px_0.5px_rgba(0,0,0,0.4)]" />
                    </div>
                  </div>
                </div>

                {/* Hero Editorial Narrative Paragraph with Tactile Moodboard Tags */}
                <p className="font-sans text-base sm:text-lg lg:text-[19px] font-normal text-[#18181B]/90 leading-[2.4] sm:leading-[2.2]">
                  I build digital homes for photographers — bringing your{' '}
                  <span className="inline-block -rotate-[1.2deg] my-1 sm:my-0 mx-0.5 sm:mx-1 px-2 sm:px-2.5 py-0.5 bg-white/95 text-[#18181B] border border-[#18181B]/20 rounded-[4px] shadow-[0_1px_3px_rgba(24,24,27,0.07)] font-sans font-medium text-[0.92em] tracking-tight hover:rotate-0 transition-transform duration-200 cursor-default select-none align-middle">
                    portfolio
                  </span>{' '}
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ebeaea] border border-[#18181B]/25 mx-1 sm:mx-1.5 align-middle shadow-[inset_0_0.5px_1px_rgba(24,24,27,0.15)]" aria-hidden="true" />{' '}
                  <span className="inline-block rotate-[1.8deg] my-1 sm:my-0 mx-0.5 sm:mx-1 px-2.5 sm:px-3 py-0.5 bg-[#F1ECE1] text-[#18181B] border border-[#18181B]/15 rounded-full shadow-[0_1px_3px_rgba(24,24,27,0.06)] font-serif italic font-semibold text-[0.95em] hover:rotate-0 transition-transform duration-200 cursor-default select-none align-middle">
                    enquiries
                  </span>{' '}
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ebeaea] border border-[#18181B]/25 mx-1 sm:mx-1.5 align-middle shadow-[inset_0_0.5px_1px_rgba(24,24,27,0.15)]" aria-hidden="true" />{' '}
                  <span className="inline-block -rotate-[1.5deg] my-1 sm:my-0 mx-0.5 sm:mx-1 px-2 sm:px-2.5 py-0.5 bg-[#E5E1D8] text-[#18181B] border border-[#18181B]/25 rounded-[2px] shadow-[0_1px_2px_rgba(24,24,27,0.08),inset_0_1px_0_rgba(255,255,255,0.7)] font-mono text-[0.86em] font-medium tracking-tight hover:rotate-0 transition-transform duration-200 cursor-default select-none align-middle">
                    reviews
                  </span>{' '}
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#ebeaea] border border-[#18181B]/25 mx-1 sm:mx-1.5 align-middle shadow-[inset_0_0.5px_1px_rgba(24,24,27,0.15)]" aria-hidden="true" />{' '}
                  <span className="inline-block rotate-[0.9deg] my-1 sm:my-0 mx-0.5 sm:mx-1 px-2 sm:px-2.5 py-0.5 bg-white/95 text-[#18181B] border border-[#18181B]/20 rounded-[4px] shadow-[0_1px_3px_rgba(24,24,27,0.07)] font-sans font-medium text-[0.92em] tracking-tight hover:rotate-0 transition-transform duration-200 cursor-default select-none align-middle">
                    gallery gateway
                  </span>{' '}
                  under one roof.
                </p>

                {/* Subtle Pill CTA to Request Site Form */}
                <div className="pt-3 mt-3 border-t border-dashed border-[#18181B]/10 flex items-center justify-end">
                  <a
                    href="#request-site"
                    id="hero-request-design-cta"
                    onClick={(e) => {
                      e.preventDefault();
                      if (onRequestSiteClick) {
                        onRequestSiteClick();
                      } else {
                        document.getElementById("request-site")?.scrollIntoView({ behavior: "smooth" });
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#18181B]/5 hover:bg-[#18181B] text-[#18181B]/75 hover:text-white border border-[#18181B]/15 hover:border-[#18181B] font-mono text-[9px] sm:text-[10px] font-bold tracking-wider uppercase transition-all duration-200 cursor-pointer group/pill"
                  >
                    <span>REQUEST YOURS</span>
                    <span className="text-xs transition-transform group-hover/pill:translate-x-0.5">→</span>
                  </a>
                </div>
              </div>
            </div>
          </motion.div>

        </div>

        {/* Bottom Poster Frame Footer: Corner Bolts & Clickable Scroll CTA */}
        <div className="relative pb-5 sm:pb-6 px-6 sm:px-10 flex items-center justify-between border-t border-[#18181B]/8 pt-3.5 sm:pt-4">
          
          {/* Left Corner Industrial Bolt / Screw */}
          <div 
            className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-gradient-to-br from-[#F3F4F6] via-[#D1D5DB] to-[#9CA3AF] border border-[#18181B]/30 shadow-[inset_0_1px_1px_rgba(255,255,255,0.7),0_1px_2px_rgba(0,0,0,0.12)] flex items-center justify-center rotate-[26deg] select-none shrink-0" 
            title="Mounting Bolt" 
            aria-hidden="true"
          >
            <div className="relative w-2 h-2 flex items-center justify-center">
              <div className="absolute w-1.5 sm:w-2 h-px bg-[#18181B]/60 rounded-xs shadow-[0_0.5px_0.5px_rgba(0,0,0,0.4)]" />
              <div className="absolute h-1.5 sm:h-2 w-px bg-[#18181B]/60 rounded-xs shadow-[0_0.5px_0.5px_rgba(0,0,0,0.4)]" />
            </div>
          </div>

          {/* Clickable "Scroll to explore" CTA targeting next section */}
          <button
            type="button"
            onClick={onWhoIHelpClick}
            className="group inline-flex items-center gap-2 font-mono text-[10px] sm:text-[11px] tracking-[0.16em] uppercase font-bold text-[#18181B]/75 hover:text-[#18181B] px-4 py-1.5 rounded-full hover:bg-white/60 border border-transparent hover:border-[#18181B]/10 transition-all duration-300 cursor-pointer shadow-none hover:shadow-xs"
            aria-label="Scroll to explore why this works"
          >
            <span>Scroll to explore</span>
            <ArrowDown className="w-3.5 h-3.5 text-[#52525B] group-hover:translate-y-1 transition-transform duration-300 animate-bounce" />
          </button>

          {/* Right Corner Industrial Bolt / Screw */}
          <div 
            className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-gradient-to-br from-[#F3F4F6] via-[#D1D5DB] to-[#9CA3AF] border border-[#18181B]/30 shadow-[inset_0_1px_1px_rgba(255,255,255,0.7),0_1px_2px_rgba(0,0,0,0.12)] flex items-center justify-center rotate-[74deg] select-none shrink-0" 
            title="Mounting Bolt" 
            aria-hidden="true"
          >
            <div className="relative w-2 h-2 flex items-center justify-center">
              <div className="absolute w-1.5 sm:w-2 h-px bg-[#18181B]/60 rounded-xs shadow-[0_0.5px_0.5px_rgba(0,0,0,0.4)]" />
              <div className="absolute h-1.5 sm:h-2 w-px bg-[#18181B]/60 rounded-xs shadow-[0_0.5px_0.5px_rgba(0,0,0,0.4)]" />
            </div>
          </div>

        </div>

      </div>

    </section>
  );
}
